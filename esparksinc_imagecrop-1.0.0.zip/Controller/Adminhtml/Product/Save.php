<?php

namespace Esparksinc\Imagecrop\Controller\Adminhtml\Product;
   
class Save extends \Magento\Catalog\Controller\Adminhtml\Product\Save
{
    
    public function execute()
    {

        $data = $this->getRequest()->getPostValue();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $fileSystem = $objectManager->create('\Magento\Framework\Filesystem');
        $mediaPath=$fileSystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath();
        $mediaAbsulatePath = $mediaPath.'catalog/product';
        $mediaTmpPath = $mediaPath.'tmp';
        
        if($data){
        	try{

        		if($data['product']['media_gallery'] && $data['product']['media_gallery']['images']){

                    $product_id = $data['product']['stock_data']['product_id'];
                    $product = $objectManager->create('Magento\Catalog\Model\Product')->load($product_id);

                    foreach ($data['product']['media_gallery']['images'] as $value) {

                        if($value['value_id']){
                            if(array_key_exists('edited',$value) && $value['edited']=='1' ) {

                                $fileNameWithoutExt = pathinfo($value['file'], PATHINFO_FILENAME);
                                $tmpFilePath =$mediaTmpPath .'/'. $fileNameWithoutExt .'.png';

                                $image = imagecreatefrompng($tmpFilePath);
                                $newCroppedImage = $mediaAbsulatePath.$value['file'];
                                imagejpeg($image, $newCroppedImage, 100); // base image

                                $file_to_search = pathinfo($value['file'], PATHINFO_BASENAME);

                                if(is_dir($mediaAbsulatePath.'/cache')){

                                    $this->search_file($mediaAbsulatePath.'/cache',$file_to_search);
                                }

                                imagedestroy($image);
                            }
                        }
                    }
        		}

        	}catch(\Magento\Framework\Exception\LocalizedException $e){

        	}
        }
        return parent::execute();
        
    }

    private function search_file($dir,$file_to_search){

        $files = scandir($dir);

        foreach($files as $value)
        {
            $path = realpath($dir.DIRECTORY_SEPARATOR.$value);

            if(!is_dir($path)) {

                if($file_to_search == $value){
                    unlink($path);
                    break;
                }

            }else if($value != "." && $value != "..") {

                $this->search_file($path, $file_to_search);
            }  
        } 
    }

}

