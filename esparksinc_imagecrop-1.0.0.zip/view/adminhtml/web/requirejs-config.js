var config = {
    map: {
        '*': {
      //       customfunctions:'ImageCrop_Crop/js/crop',
	    	// jcropCustom:'ImageCrop_Crop/js/jcropCustom'

        }
    }
};
