var config = {
    map: {
        '*': {
            customfunctions:'Esparksinc_Imagecrop/js/crop',
	    	jcropCustom:'Esparksinc_Imagecrop/js/jcropCustom'

        }
    }
};
