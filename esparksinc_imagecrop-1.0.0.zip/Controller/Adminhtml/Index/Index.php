<?php 
/**
 *
 * Copyright © 2017 Magento, Inc. All rights reserved.
 * 
 */
namespace Esparksinc\Imagecrop\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Catalog\Model\Product;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

/**
  * Class Index
  * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
  */

class Index extends Action
{

    /**
      * Directory List
      *
      * @var DirectoryList
      */
    protected $directoryList;

    /**
      * File interface
      *
      * @var File
      */
    protected $file;

    /**
      * ImportImageService constructor
      *
      * @param DirectoryList $directoryList
      * @param File $file
      */

    public function __construct(\Magento\Backend\App\Action\Context $context , DirectoryList $directoryList , File $file)
    {
        parent::__construct($context);
        $this->directoryList = $directoryList;
        $this->file = $file;
    }

    public function execute()
    {
      // function save_base64_image() {
          $base64_image_string=$this->getRequest()->getParam('base64_image_string');  //Base64 Image
          $output_file_without_extension=$this->getRequest()->getParam('output_file_without_extension'); //Image Name
          $path_with_end_slash=$this->getRequest()->getParam('path_with_end_slash'); //Path for Image
          $imgurl = $this->getRequest()->getParam('imgurl'); //Full Orignal Image Path with Name

          $splited = explode(',' , substr($base64_image_string , 5) , 2);
          $mime=$splited[0];
          $data=$splited[1];

          $mime_split_without_base64=explode(';' , $mime , 2);
          $mime_split=explode('/' , $mime_split_without_base64[0] , 2);

          if( count($mime_split)==2 ){
              $extension=$mime_split[1];
              if($extension=='jpeg'){
                $extension='jpg';
              }
              $output_file_with_extension=$output_file_without_extension.'.'.$extension;
          }

          $explode=explode('.', $imgurl); // split all parts
          $end = '';
          $begin = '';

          if( count($explode) > 0 ){
              $end = array_pop($explode); // removes the last element, and returns it
              if( count($explode) > 0 ){
                  $begin = implode('.', $explode); // glue the remaining pieces back together
              }
          }

          $tmpDir=$this->getMediaDirTmpDir();

          $dirname=pathinfo($imgurl, PATHINFO_DIRNAME);
          /** create folder if it is not exists */
          $this->file->checkAndCreateFolder($tmpDir);

          if(strpos($imgurl, 'tmp')===false){
              $newFileName = $tmpDir .'/'.pathinfo($imgurl, PATHINFO_FILENAME).'.png';
              file_put_contents( $newFileName, base64_decode($data) );
              $arr = explode('media', $imgurl);
          }else{
                  $newFileName = $tmpDir .'/'.pathinfo($imgurl, PATHINFO_FILENAME).'.png';
                  file_put_contents( $newFileName, base64_decode($data) );
                  $arr = explode('tmp', $imgurl);
                  $image = imagecreatefrompng($newFileName);

                if(pathinfo($arr[1], PATHINFO_EXTENSION)=='jpg' || pathinfo($arr[1], PATHINFO_EXTENSION)=='jpeg' ){
                    imagejpeg($image,$tmpDir.$arr[1], 100);
                    imagedestroy($image);
                    unlink($newFileName);
                }elseif(pathinfo($arr[1], PATHINFO_EXTENSION)=='png'){
                          move_uploaded_file($newFileName,$tmpDir.$arr[1]);
                          unlink($newFileName);
                }
          }
          $result = array('tmp img path '=> $newFileName , 'orignal image path' => $tmpDir.$arr[1]);
          print_r( json_encode($result));
    }

    protected function getMediaDirTmpDir()
    {
        return $this->directoryList->getPath(DirectoryList::MEDIA) . DIRECTORY_SEPARATOR . 'tmp';
    }

    protected function get_image_type($target_file)
    {
        $imageFileType = pathinfo($target_file , PATHINFO_EXTENSION);
        return $imageFileType;
    }


}
