define(['jquery'],function($) {
    'use strict';
    return  {
        save_image: function (id) {
          //alert("I am here");

        var someimage = document.getElementById('fig'+id).firstChild.getAttribute("src");
		console.log(someimage);

        },

        test: function () {
          console.log("this is test");
        },

    }

});